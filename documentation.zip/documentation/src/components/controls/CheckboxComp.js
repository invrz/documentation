import React, {Component} from "react"
import '../fluent.css';

class TextInput extends Component{
  
  render(){
    return(
        <h1>Hello, Do you think it's working</h1>
    );
  }

}


export default TextInput;
